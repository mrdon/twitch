=/\=

The font is called Jefferies Extended. As seen in opening title Logo of Star Trek Enterprise on UPN. 

This is available for PC and MAC.

Designed by Jeff Yerkey (www.trek5.com) in honor of Matt Jefferies and Michael Okuda.

2005